#!/bin/bash
input=$1
output=$2
intensity="intensity.csv"
dtg="dtg.csv"
minSeaLevelPres="minSeaLevelPres.csv"
lat="lat.csv"
lon="lon.csv"
echo "Timestamp,Latitude,Longitude,MinSeaLevelPressure,MaxIntensity" > $output
grep "<intensity>" $input | sed 's/<\/intensity>//' | sed 's/<intensity>//' | sed 's/^\s*//;s/\s*$//' > "$intensity"
grep "<dtg>" $input | sed 's/<\/dtg>//' | sed 's/<dtg>//' | sed 's/^\s*//;s/\s*$//' > "$dtg"
grep "<minSeaLevelPres>" $input | sed 's/<\/minSeaLevelPres>//' | sed 's/<minSeaLevelPres>//' | sed 's/^\s*//;s/\s*$//' > "$minSeaLevelPres"
grep "<lat>" $input | sed 's/<\/lat>//' | sed 's/<lat>//' | sed 's/^\s*//;s/\s*$//' > "$lat" 
grep "<lon>" $input | sed 's/<\/lon>//' | sed 's/<lon>//' | sed 's/^\s*//;s/\s*$//' > "$lon"
sed -i 's/$/ N/' $lat 
sed -i 's/$/ knots/' $intensity
sed -i 's/$/ mb/' $minSeaLevelPres
sed -i 's/$/ W/' $lon   
paste -d, dtg.csv lat.csv lon.csv minSeaLevelPres.csv intensity.csv | tr '\t' ',' >> $output
rm $dtg $lat $lon $minSeaLevelPres $intensity
